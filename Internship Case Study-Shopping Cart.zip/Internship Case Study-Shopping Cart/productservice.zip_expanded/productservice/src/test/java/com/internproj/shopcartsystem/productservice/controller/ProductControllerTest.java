package com.internproj.shopcartsystem.productservice.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JsonParseException;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.base.Optional;
import com.internproj.shopcartsystem.productservice.entities.Product;
import com.internproj.shopcartsystem.productservice.repositories.ProductRepository;
import com.internproj.shopcartsystem.productservice.services.ProductService;


@SpringBootTest(classes = ProductController.class)
class ProductControllerTest {

	@Autowired
	ProductService service;
	
	@MockBean
	ProductRepository repository;
	
	@BeforeEach
	void setup() {
		Optional<Product> product = Optional.of(new Product(1, "Iphone14", 150000, "Android Phone", "Black, 128GB"));
		Mockito.when(repository.findAllByProdName("Iphone14")).thenReturn((List<Product>) product);
	}
	
	@Test
	public void test_viewProductByProdId() {
		String prodName = "Iphone14";
		List<Product> prodByName = service.viewProductsByProdName(prodName);
		assertEquals(prodName, prodByName.get(0));
	}
	
	
}
